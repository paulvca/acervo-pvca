import { chromium } from 'playwright-core';
import robotsParser from 'robots-parser';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

const START_URL = process.env.START_URL;
const OUT = process.env.OUT;
const MAX_PAGES = Number(process.env.MAX_PAGES || 1000);
const MIN_DELAY_MS = Number(process.env.MIN_DELAY_MS || 650);
const BROWSER_CHANNEL = process.env.BROWSER_CHANNEL || '';
const BROWSER_EXEC = process.env.BROWSER_EXEC || '';

if (!START_URL || !OUT)
  throw new Error('START_URL/OUT ausentes.');

const START = new URL(START_URL);

const ALLOWED_HOSTS = new Set([
  'noahzender.com',
  'www.noahzender.com'
]);

const USER_AGENT_ROBOTS = 'PVCA-Structure-Study';

const sleep = ms =>
  new Promise(resolve => setTimeout(resolve, ms));

async function mkdirp(p) {
  await fs.mkdir(p, { recursive: true });
}

async function writeText(file, text) {
  await mkdirp(path.dirname(file));
  await fs.writeFile(file, text, 'utf8');
}

async function writeJson(file, value) {
  await writeText(
    file,
    JSON.stringify(value, null, 2) + '\n'
  );
}

function canonicalize(input, base = START_URL) {
  try {
    const u = new URL(input, base);

    if (!['http:', 'https:'].includes(u.protocol))
      return null;

    if (!ALLOWED_HOSTS.has(u.hostname.toLowerCase()))
      return null;

    u.hash = '';
    u.search = '';

    if (u.pathname.length > 1)
      u.pathname = u.pathname.replace(/\/+$/, '');

    u.protocol = 'https:';
    u.hostname = 'www.noahzender.com';

    return u.href;
  } catch {
    return null;
  }
}

function looksLikePage(url) {
  const p = new URL(url).pathname.toLowerCase();

  return !/\.(?:avif|bmp|css|csv|docx?|eot|gif|gz|ico|jpe?g|js|json|map|mov|mp3|mp4|pdf|png|rar|rss|svg|tar|tiff?|ttf|txt|wav|webm|webp|woff2?|xml|zip)$/i.test(p);
}

function pageKey(url) {
  const u = new URL(url);

  const readable = (
    u.pathname === '/' ? 'home' : u.pathname
  )
    .replace(/^\/+|\/+$/g, '')
    .replace(/[^a-zA-Z0-9._-]+/g, '__')
    .slice(0, 120) || 'home';

  const hash = crypto
    .createHash('sha1')
    .update(url)
    .digest('hex')
    .slice(0, 10);

  return `${readable}--${hash}`;
}

function xmlLocs(xml) {
  return [
    ...xml.matchAll(/<loc>\s*([^<]+?)\s*<\/loc>/gi)
  ].map(m => m[1].trim());
}

async function fetchText(url) {
  const res = await fetch(url, {
    headers: {
      'user-agent': USER_AGENT_ROBOTS
    },
    redirect: 'follow'
  });

  if (!res.ok)
    return {
      ok: false,
      status: res.status,
      text: ''
    };

  return {
    ok: true,
    status: res.status,
    text: await res.text()
  };
}

/*
 * O sitemap serve também para encontrar páginas públicas
 * que eventualmente não estejam ligadas diretamente da home.
 */
async function collectSitemaps() {
  const seen = new Set();
  const urls = new Set();

  const queue = [
    new URL('/sitemap.xml', START).href
  ];

  while (queue.length && seen.size < 20) {
    const sm = queue.shift();

    if (seen.has(sm))
      continue;

    seen.add(sm);

    const r = await fetchText(sm);

    if (!r.ok)
      continue;

    await writeText(
      path.join(
        OUT,
        'discovery',
        `sitemap-${seen.size}.xml`
      ),
      r.text
    );

    for (const loc of xmlLocs(r.text)) {
      if (/\.xml(?:$|\?)/i.test(loc)) {
        try {
          const su = new URL(loc);

          if (
            ALLOWED_HOSTS.has(
              su.hostname.toLowerCase()
            )
          ) {
            queue.push(loc);
          }
        } catch {}

        continue;
      }

      const c = canonicalize(loc);

      if (c && looksLikePage(c))
        urls.add(c);
    }
  }

  return [...urls];
}

/*
 * DOM estrutural:
 * preserva tags, classes, IDs, links, ARIA e data-*,
 * mas não despeja nós de texto no relatório estrutural.
 */
function structuralTreeScript() {
  return `(() => {
    const keep = name =>
      name === 'id' ||
      name === 'class' ||
      name === 'href' ||
      name === 'src' ||
      name === 'role' ||
      name === 'name' ||
      name === 'type' ||
      name === 'rel' ||
      name === 'target' ||
      name === 'title' ||
      name === 'alt' ||
      name === 'tabindex' ||
      name.startsWith('data-') ||
      name.startsWith('aria-');

    const voids = new Set([
      'area','base','br','col','embed','hr',
      'img','input','link','meta','param',
      'source','track','wbr'
    ]);

    const lines = [];

    function walk(el, depth) {
      if (!(el instanceof Element))
        return;

      const attrs = [...el.attributes]
        .filter(a => keep(a.name))
        .map(a => {
          const v = a.value
            .replace(/\\\\s+/g, ' ')
            .trim();

          return v
            ? a.name + '=\\\\\"' +
              v.slice(0, 240)
                .replaceAll('\\\\\"', '&quot;') +
              (v.length > 240 ? '…' : '') +
              '\\\\\"'
            : a.name;
        });

      const tag = el.tagName.toLowerCase();

      lines.push(
        '  '.repeat(depth) +
        '<' +
        tag +
        (attrs.length ? ' ' + attrs.join(' ') : '') +
        '>'
      );

      for (const child of el.children)
        walk(child, depth + 1);

      if (!voids.has(tag)) {
        lines.push(
          '  '.repeat(depth) +
          '</' +
          tag +
          '>'
        );
      }
    }

    walk(document.documentElement, 0);

    return lines.join('\\\\n');
  })()`;
}

/*
 * Snapshot geométrico/computed-style dos elementos.
 * Isto é o que permite comparar de verdade desktop/mobile.
 */
function layoutScript() {
  return `(() => {
    function pathFor(el) {
      if (el === document.documentElement)
        return 'html';

      const parts = [];
      let n = el;

      while (
        n &&
        n.nodeType === 1 &&
        n !== document.documentElement
      ) {
        let part = n.tagName.toLowerCase();

        if (n.id) {
          part += '#' + CSS.escape(n.id);
          parts.unshift(part);
          break;
        }

        const parent = n.parentElement;

        if (parent) {
          const same = [...parent.children]
            .filter(x => x.tagName === n.tagName);

          if (same.length > 1) {
            part += ':nth-of-type(' +
              (same.indexOf(n) + 1) +
              ')';
          }
        }

        parts.unshift(part);
        n = parent;
      }

      return ['html', ...parts].join(' > ');
    }

    return [...document.querySelectorAll('*')]
      .map(el => {
        const s = getComputedStyle(el);
        const r = el.getBoundingClientRect();

        return {
          path: pathFor(el),
          tag: el.tagName.toLowerCase(),
          id: el.id || null,
          class:
            typeof el.className === 'string'
              ? el.className
              : null,

          visible:
            !!(r.width || r.height) &&
            s.display !== 'none' &&
            s.visibility !== 'hidden' &&
            Number(s.opacity || 1) !== 0,

          x: Math.round(r.x * 100) / 100,
          y: Math.round(r.y * 100) / 100,
          width: Math.round(r.width * 100) / 100,
          height: Math.round(r.height * 100) / 100,

          display: s.display,
          position: s.position,

          flexDirection: s.flexDirection,
          gridTemplateColumns:
            s.gridTemplateColumns,
          gap: s.gap,

          fontFamily: s.fontFamily,
          fontSize: s.fontSize,
          fontWeight: s.fontWeight,
          lineHeight: s.lineHeight,
          textAlign: s.textAlign,

          color: s.color,
          backgroundColor:
            s.backgroundColor,

          padding: s.padding,
          margin: s.margin
        };
      });
  })()`;
}

function mediaQueryScript() {
  return `(() => {
    const found = new Set();

    function scan(rules) {
      if (!rules)
        return;

      for (const rule of rules) {
        if (rule.type === CSSRule.MEDIA_RULE)
          found.add(rule.conditionText);

        try {
          if (rule.cssRules)
            scan(rule.cssRules);
        } catch {}
      }
    }

    for (const sheet of document.styleSheets) {
      try {
        scan(sheet.cssRules);
      } catch {}
    }

    return [...found].sort();
  })()`;
}

/*
 * Percorre verticalmente a página para disparar
 * lazy loading antes do snapshot final.
 */
async function lazyLoad(page) {
  await page.evaluate(async () => {
    const delay = ms =>
      new Promise(r => setTimeout(r, ms));

    const max = Math.max(
      document.body.scrollHeight,
      document.documentElement.scrollHeight
    );

    const step = Math.max(
      500,
      Math.floor(window.innerHeight * 0.8)
    );

    for (
      let y = 0;
      y < max;
      y += step
    ) {
      window.scrollTo(0, y);
      await delay(60);
    }

    window.scrollTo(0, 0);
    await delay(150);
  }).catch(() => {});
}

async function captureOne(
  context,
  profile,
  url,
  key
) {
  const page = await context.newPage();

  const dir = path.join(
    OUT,
    profile,
    key
  );

  await mkdirp(dir);

  const errors = [];

  page.on('pageerror', err => {
    errors.push({
      type: 'pageerror',
      message: String(err)
    });
  });

  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push({
        type: 'console.error',
        message: msg.text()
      });
    }
  });

  let response;
  let raw = '';
  let status = null;
  let finalUrl = url;

  try {
    response = await page.goto(url, {
      waitUntil: 'domcontentloaded',
      timeout: 45000
    });

    status = response?.status() ?? null;
    finalUrl = page.url();

    if (response) {
      raw = await response
        .text()
        .catch(() => '');
    }

    await page.waitForTimeout(900);

    await lazyLoad(page);

  } catch (err) {
    errors.push({
      type: 'navigation',
      message: String(err)
    });
  }

  const rendered =
    await page.content()
      .catch(() => '');

  const structure =
    await page.evaluate(
      structuralTreeScript()
    ).catch(
      err => `ERROR: ${err}`
    );

  const layout =
    await page.evaluate(
      layoutScript()
    ).catch(
      err => [{
        error: String(err)
      }]
    );

  const mediaQueries =
    await page.evaluate(
      mediaQueryScript()
    ).catch(() => []);

  const links =
    await page
      .locator('a[href]')
      .evaluateAll(
        (els, base) =>
          els
            .map(a => {
              try {
                return new URL(
                  a.getAttribute('href'),
                  base
                ).href;
              } catch {
                return null;
              }
            })
            .filter(Boolean),
        page.url()
      )
      .catch(() => []);

  const stylesheets =
    await page
      .locator(
        'link[rel~="stylesheet"][href]'
      )
      .evaluateAll(
        (els, base) =>
          els
            .map(x => {
              try {
                return new URL(
                  x.getAttribute('href'),
                  base
                ).href;
              } catch {
                return null;
              }
            })
            .filter(Boolean),
        page.url()
      )
      .catch(() => []);

  if (raw) {
    await writeText(
      path.join(dir, 'raw.html'),
      raw
    );
  }

  await writeText(
    path.join(dir, 'rendered.html'),
    rendered
  );

  await writeText(
    path.join(dir, 'dom-structure.txt'),
    structure + '\n'
  );

  await writeJson(
    path.join(dir, 'layout.json'),
    layout
  );

  await writeJson(
    path.join(dir, 'media-queries.json'),
    mediaQueries
  );

  await writeJson(
    path.join(dir, 'links.json'),
    links
  );

  await writeJson(
    path.join(dir, 'stylesheets.json'),
    stylesheets
  );

  await writeJson(
    path.join(dir, 'errors.json'),
    errors
  );

  try {
    await page.screenshot({
      path: path.join(
        dir,
        'full-page.jpg'
      ),
      fullPage: true,
      type: 'jpeg',
      quality: 82
    });

  } catch (err) {
    errors.push({
      type: 'screenshot',
      message: String(err)
    });

    await writeJson(
      path.join(dir, 'errors.json'),
      errors
    );
  }

  await page.close();

  return {
    profile,
    requestedUrl: url,
    finalUrl,
    status,
    links,
    stylesheets,
    mediaQueries,
    errors,
    layout
  };
}

function diffLayouts(desktop, mobile) {
  const d = new Map(
    desktop
      .filter(x => x?.path)
      .map(x => [x.path, x])
  );

  const m = new Map(
    mobile
      .filter(x => x?.path)
      .map(x => [x.path, x])
  );

  const desktopOnly =
    [...d.keys()]
      .filter(k => !m.has(k));

  const mobileOnly =
    [...m.keys()]
      .filter(k => !d.has(k));

  const fields = [
    'visible',
    'display',
    'position',
    'flexDirection',
    'gridTemplateColumns',
    'gap',
    'fontSize',
    'fontWeight',
    'lineHeight',
    'textAlign',
    'padding',
    'margin'
  ];

  const changed = [];

  for (const [k, a] of d) {
    const b = m.get(k);

    if (!b)
      continue;

    const delta = {};

    for (const f of fields) {
      if (a[f] !== b[f]) {
        delta[f] = {
          desktop: a[f],
          mobile: b[f]
        };
      }
    }

    const widthDelta =
      Math.abs(
        (a.width || 0) -
        (b.width || 0)
      );

    const heightDelta =
      Math.abs(
        (a.height || 0) -
        (b.height || 0)
      );

    if (widthDelta >= 1) {
      delta.width = {
        desktop: a.width,
        mobile: b.width
      };
    }

    if (heightDelta >= 1) {
      delta.height = {
        desktop: a.height,
        mobile: b.height
      };
    }

    if (Object.keys(delta).length) {
      changed.push({
        path: k,
        delta
      });
    }
  }

  return {
    desktopOnly,
    mobileOnly,
    changed
  };
}

/* robots.txt */
const robotsUrl =
  new URL(
    '/robots.txt',
    START
  ).href;

let robotsText = '';

try {
  const rr =
    await fetchText(robotsUrl);

  robotsText =
    rr.ok ? rr.text : '';

  await writeText(
    path.join(
      OUT,
      'discovery',
      'robots.txt'
    ),
    robotsText ||
      `# robots.txt indisponível (HTTP ${rr.status})\n`
  );

} catch (err) {
  await writeText(
    path.join(
      OUT,
      'discovery',
      'robots.txt'
    ),
    `# erro ao obter robots.txt: ${err}\n`
  );
}

const robots =
  robotsParser(
    robotsUrl,
    robotsText
  );

const robotsDelay =
  Number(
    robots.getCrawlDelay(
      USER_AGENT_ROBOTS
    ) ||
    robots.getCrawlDelay('*') ||
    0
  ) * 1000;

const delayMs =
  Math.max(
    MIN_DELAY_MS,
    Number.isFinite(robotsDelay)
      ? robotsDelay
      : 0
  );

/* Navegador */
const launchOptions = {
  headless: true
};

if (BROWSER_CHANNEL) {
  launchOptions.channel =
    BROWSER_CHANNEL;
} else if (BROWSER_EXEC) {
  launchOptions.executablePath =
    BROWSER_EXEC;
} else {
  throw new Error(
    'Nenhum navegador configurado.'
  );
}

const browser =
  await chromium.launch(
    launchOptions
  );

/*
 * Primeiro descobrimos o UA real do navegador instalado.
 * O mobile usa a mesma versão de Chromium, mas anuncia Android.
 */
const probe =
  await browser.newContext();

const probePage =
  await probe.newPage();

const desktopUA =
  await probePage.evaluate(
    () => navigator.userAgent
  );

await probe.close();

const chromeVersion =
  desktopUA.match(
    /(?:Chrome|Edg)\/([\d.]+)/
  )?.[1] || '140.0.0.0';

const mobileUA =
  `Mozilla/5.0 (Linux; Android 14; Pixel 7) ` +
  `AppleWebKit/537.36 (KHTML, like Gecko) ` +
  `Chrome/${chromeVersion} Mobile Safari/537.36`;

const desktop =
  await browser.newContext({
    viewport: {
      width: 1440,
      height: 900
    },
    deviceScaleFactor: 1,
    locale: 'en-US'
  });

const mobile =
  await browser.newContext({
    viewport: {
      width: 412,
      height: 915
    },
    deviceScaleFactor: 2.625,
    isMobile: true,
    hasTouch: true,
    userAgent: mobileUA,
    locale: 'en-US'
  });

/* Descoberta inicial */
const sitemapSeeds =
  await collectSitemaps();

const start =
  canonicalize(START_URL);

const queue =
  [
    start,
    ...sitemapSeeds
  ].filter(Boolean);

const queued =
  new Set(queue);

const visited =
  new Set();

const manifest = [];

const allStylesheets =
  new Set();

while (
  queue.length &&
  visited.size < MAX_PAGES
) {
  const url = queue.shift();

  if (
    !url ||
    visited.has(url)
  ) {
    continue;
  }

  const allowed =
    robots.isAllowed(
      url,
      USER_AGENT_ROBOTS
    );

  if (allowed === false) {
    manifest.push({
      url,
      skipped: 'robots.txt'
    });

    visited.add(url);

    await writeJson(
      path.join(
        OUT,
        'manifest.json'
      ),
      manifest
    );

    continue;
  }

  visited.add(url);

  const key =
    pageKey(url);

  process.stdout.write(
    `[${visited.size}/${Math.min(
      MAX_PAGES,
      visited.size + queue.length
    )}] ${url}\n`
  );

  /*
   * Desktop
   */
  const d =
    await captureOne(
      desktop,
      'desktop',
      url,
      key
    );

  await sleep(delayMs);

  /*
   * Mobile
   */
  const m =
    await captureOne(
      mobile,
      'mobile',
      url,
      key
    );

  await sleep(delayMs);

  /*
   * Descobre novas páginas nos dois DOMs.
   */
  for (
    const href of [
      ...d.links,
      ...m.links
    ]
  ) {
    const c =
      canonicalize(
        href,
        url
      );

    if (
      !c ||
      !looksLikePage(c) ||
      visited.has(c) ||
      queued.has(c)
    ) {
      continue;
    }

    queued.add(c);
    queue.push(c);
  }

  for (
    const s of [
      ...d.stylesheets,
      ...m.stylesheets
    ]
  ) {
    allStylesheets.add(s);
  }

  /*
   * Comparação automática desktop/mobile.
   */
  const diff =
    diffLayouts(
      d.layout,
      m.layout
    );

  await writeJson(
    path.join(
      OUT,
      'diff',
      `${key}.json`
    ),
    diff
  );

  manifest.push({
    key,
    url,

    desktop: {
      finalUrl: d.finalUrl,
      status: d.status,
      errors: d.errors.length
    },

    mobile: {
      finalUrl: m.finalUrl,
      status: m.status,
      errors: m.errors.length
    },

    diff: {
      desktopOnly:
        diff.desktopOnly.length,

      mobileOnly:
        diff.mobileOnly.length,

      changed:
        diff.changed.length
    }
  });

  /*
   * Persistência incremental:
   * Ctrl+C não apaga o que já foi descoberto.
   */
  await writeJson(
    path.join(
      OUT,
      'manifest.json'
    ),
    manifest
  );
}

await writeJson(
  path.join(
    OUT,
    'manifest.json'
  ),
  manifest
);

await desktop.close();
await mobile.close();
await browser.close();

/*
 * Baixa somente CSS referenciado.
 * Não espelha imagens/vídeos/fontes desnecessariamente.
 */
const cssIndex = [];
let cssN = 0;

for (
  const href of [
    ...allStylesheets
  ].sort()
) {
  cssN += 1;

  const rec = {
    url: href,
    saved: null,
    status: null,
    error: null
  };

  try {
    const r =
      await fetch(
        href,
        {
          redirect: 'follow'
        }
      );

    rec.status =
      r.status;

    if (r.ok) {
      const css =
        await r.text();

      const name =
        `${String(cssN)
          .padStart(3, '0')}-` +
        crypto
          .createHash('sha1')
          .update(href)
          .digest('hex')
          .slice(0, 10) +
        '.css';

      await writeText(
        path.join(
          OUT,
          'css',
          name
        ),
        css
      );

      rec.saved =
        `css/${name}`;
    }

  } catch (err) {
    rec.error =
      String(err);
  }

  cssIndex.push(rec);
}

await writeJson(
  path.join(
    OUT,
    'css-index.json'
  ),
  cssIndex
);

/*
 * Consolidação das media queries detectadas.
 */
const mediaSet =
  new Set();

for (const item of manifest) {
  if (!item.key)
    continue;

  for (
    const profile of [
      'desktop',
      'mobile'
    ]
  ) {
    try {
      const q =
        JSON.parse(
          await fs.readFile(
            path.join(
              OUT,
              profile,
              item.key,
              'media-queries.json'
            ),
            'utf8'
          )
        );

      for (const x of q)
        mediaSet.add(x);

    } catch {}
  }
}

await writeText(
  path.join(
    OUT,
    'all-media-queries.txt'
  ),
  [...mediaSet]
    .sort()
    .join('\n') +
    '\n'
);

await writeJson(
  path.join(
    OUT,
    'summary.json'
  ),
  {
    startUrl: START_URL,
    capturedAt:
      new Date().toISOString(),

    pagesVisited:
      visited.size,

    manifestEntries:
      manifest.length,

    remainingQueue:
      queue.length,

    maxPages:
      MAX_PAGES,

    delayMs,

    sitemapSeeds:
      sitemapSeeds.length,

    stylesheets:
      cssIndex.length,

    desktopViewport:
      '1440x900',

    mobileViewport:
      '412x915',

    desktopUserAgent:
      desktopUA,

    mobileUserAgent:
      mobileUA
  }
);

console.log(
  `\nConcluído: ${visited.size} páginas processadas.`
);

console.log(
  `Saída: ${OUT}`
);
