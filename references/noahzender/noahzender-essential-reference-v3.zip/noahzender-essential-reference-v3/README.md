# Noah Zender — referência estrutural auditada v2

Esta é a versão corrigida da redução da captura usada como referência para o
Acervo PVCA.

## Garantias desta versão

- Todas as **493 rotas** permanecem representadas.
- O `raw.html` de todas as rotas foi preservado uma vez, porque desktop e mobile
  eram exatamente iguais em **493/493** páginas.
- O HTML renderizado e a árvore DOM de todas as rotas foram preservados.
- Os `layout.json` de **desktop e mobile de todas as rotas** foram preservados.
- Todos os **493 diffs responsivos** foram preservados.
- O corpo (`<body>`) renderizado é idêntico entre desktop e mobile em
  **493/493** páginas.
- As **9** diferenças de documento renderizado
  ocorreram no `<head>`; mesmo assim, suas variantes mobile foram preservadas.
- O CSS capturado, sitemap, robots, manifest, summary, script e lockfile foram
  preservados.
- As screenshots foram reduzidas para **13 rotas**, escolhidas
  para cobrir **103/103 padrões estruturais**
  observados, além de variações de comprimento.

## O que foi removido com segurança

- `node_modules/`: reinstalável pelo `package-lock.json`.
- Cópias mobile de `raw.html`: eram byte a byte idênticas às desktop.
- Cópias repetidas de `media-queries.json`, `stylesheets.json` e `errors.json`:
  cada categoria tinha apenas um hash único em toda a captura.
- Screenshots de rotas cujo vocabulário estrutural já está coberto pelas
  referências visuais preservadas.

## Por que esta v2 substitui a v1

A v1 preservava 101 de 103 assinaturas estruturais detectadas. Faltavam
`<blockquote>` e `<mark>`. A v2 mantém todo HTML/DOM e escolhe referências
visuais com cobertura de 103/103 assinaturas.

Use `audit/audit-summary.json` e `audit/structural-signatures.json` para conferir
as evidências da redução.


## Terceira auditoria independente

A v3 foi comparada novamente contra o ZIP original, sem depender apenas das
regras usadas para construir a v2.

Resultado:

- rotas ausentes: 0;
- rotas extras: 0;
- colisões no mapeamento de diretórios: 0;
- divergências de hash nos arquivos estruturais por rota: 0;
- divergências no inventário semântico HTML: 0;
- CSS: idêntico byte a byte;
- vocabulário HTML preservado: tags, classes, IDs e atributos sem perdas;
- inventário adicional de assets/scripts/links externos incluído em `audit/`;
- manifest SHA-256 de todos os arquivos incluído em `audit/file-sha256.json`.

A única redução material remanescente é de screenshots repetitivas. Isso não
remove a estrutura nem a responsividade computada, pois cada rota conserva o
HTML renderizado e os layouts desktop/mobile exatos.
